# 2 - Econometria Avançada - Aula2
Slides e códigos da segunda aula de Econometria avançada.
